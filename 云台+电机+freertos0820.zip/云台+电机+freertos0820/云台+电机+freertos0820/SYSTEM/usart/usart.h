/***********************************************
��˾����Ȥ�Ƽ�(��ݸ)���޹�˾
Ʒ�ƣ�WHEELTEC
������wheeltec.net
�Ա����̣�shop114407458.taobao.com 
����ͨ: https://minibalance.aliexpress.com/store/4455017
�汾��V1.0
�޸�ʱ�䣺2022-10-13

Brand: WHEELTEC
Website: wheeltec.net
Taobao shop: shop114407458.taobao.com 
Aliexpress: https://minibalance.aliexpress.com/store/4455017
Version: V1.0
Update��2022-10-13

All rights reserved
***********************************************/
#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "sys.h" 

#include "FreeRTOS.h"
#include "semphr.h"

#define RCV_SIZE 32

extern SemaphoreHandle_t uartSemaphore;
extern u8 Recv[RCV_SIZE];
extern u8 rx_cnt;

//��pid��
extern SemaphoreHandle_t uartSemaphore_pid;
extern u8 Recv_pid[RCV_SIZE];
extern u8 rx_cnt_pid;

void uart_init(u32 bound);
void usart1_send(u8 data);
void USART1_IRQHandler(void);
void usart1_sendAngleBlock(int Angle_A, int Angle_B);
void USART1_Init(void);

//��pid��
void uart_init_pid(u32 bound);
void usart2_send(u8 data);
void USART2_IRQHandler(void);
#endif


